class Produto {
    constructor() {
        this.id = 1;
        this.arrayProdutos = [];
    }
    salvar() {
        let produto = this.lerDados();       
        this.adicionar(produto);
        this.listaTabela();
    }
    adicionar(produto) {
        let array = this.arrayProdutos;
        let inserir = true;
        for (let i = 0; i < this.arrayProdutos.length; i++) {//conferir se existe produtos com mesmo Id
            if (this.arrayProdutos[i].id == array[i].id) {//caso exista irei apenas mudar a quantidade
                inserir = false;
                this.arrayProdutos[i].qtde = parseInt(this.arrayProdutos[i].qtde) + parseInt(produto.qtde);//produto.qtde estou pegando valor do input digitado, pois é do array de mesmo id
            }
        }
        if (inserir) {
            this.arrayProdutos.push(produto);          
        }     
    }
    lerDados() {
        let produto = {}
        produto.id = this.id;
        produto.nomeProduto = "Hamburguer";
        produto.qtde = "3";
        produto.preco = "19";
        return produto;
    }
    listaTabela() {
        let tbody = document.getElementById('tbody');
        tbody.innerText = '';//sempre que adicino um novo valor ao array, ele limpa os dados da tabela, para que assim não haja repetição, porque o for ele passa denovo pelo mesmo lugar do array
        for (let i = 0; i < this.arrayProdutos.length; i++) {
            let tr = tbody.insertRow(); //criar uma nova linha para a tabela
            let td_id = tr.insertCell(); //adiciona as colunas para a linha
            let td_nome = tr.insertCell();
            let td_qtde = tr.insertCell();
            let td_preco = tr.insertCell();
            let td_acao = tr.insertCell();

            td_id.innerText = this.arrayProdutos[i].id;//dou valor as linhas da tabela
            td_nome.innerText = this.arrayProdutos[i].nomeProduto;
            td_preco.innerText = (this.arrayProdutos[i].preco * this.arrayProdutos[i].qtde);

            let qtdeEditar = document.createElement('input');//criei um input do tipo number
            qtdeEditar.type = 'text';
            let qtdeDiminuir = document.createElement('Input')
            let qtdeAumentar = document.createElement('Input')
            qtdeDiminuir.type = 'button';
            qtdeAumentar.type = 'button';
            qtdeDiminuir.value = '-';
            qtdeAumentar.value = '+';
            qtdeEditar.value = this.arrayProdutos[i].qtde;//dei o valor da quantidade do indice (i) do array
            td_qtde.appendChild(qtdeDiminuir);
            td_qtde.appendChild(qtdeEditar);
            td_qtde.appendChild(qtdeAumentar);
            qtdeDiminuir.setAttribute('onclick', 'produto.DiminuirQtde(' + this.arrayProdutos[i].id + ')');
            qtdeAumentar.setAttribute('onclick', 'produto.AumentarQtde(' + this.arrayProdutos[i].id + ')');

            let imgEditar = document.createElement('img'); //essa variavel cria uma tag HTML, <img>
            imgEditar.src = 'deletar.png';
            imgEditar.setAttribute('onclick', 'produto.deletar(' + this.arrayProdutos[i].id + ')');//1°arg: Dou uma ação a imagem, e segundo passo o que a ação irá fazer
            td_acao.appendChild(imgEditar); //dentro de um td, vair ter um outro elemento, nesse caso a imagem
        }
    }
    deletar(idDeletar) {
        if (confirm("Deseja realmente deletar?")) {
            let tbody = document.getElementById('tbody');

            for (let i = 0; i < this.arrayProdutos.length; i++) {
                if (this.arrayProdutos[i].id == idDeletar) {
                    this.arrayProdutos.splice(i, 1);//essa função deleta um array por meio do indice passado (i), e deletará apenas um registro
                    tbody.deleteRow(i);//deleto da tabela a linha com o indice enviado
                }
            }
        }
    }
    DiminuirQtde(idSubtrair) {
        let tbody = document.getElementById('tbody');
        for (let i = 0; i < this.arrayProdutos.length; i++) {
            if (this.arrayProdutos[i].id == idSubtrair) {
                this.arrayProdutos[i].qtde = parseInt(this.arrayProdutos[i].qtde) - 1;
            }
        }
        this.listaTabela();
    }
    AumentarQtde(idAumentar) {
        let tbody = document.getElementById('tbody');
        for (let i = 0; i < this.arrayProdutos.length; i++) {
            if (this.arrayProdutos[i].id == idAumentar) {
                this.arrayProdutos[i].qtde = parseInt(this.arrayProdutos[i].qtde) + 1;
            }
        }
        this.listaTabela();
    }
}
var produto = new Produto();