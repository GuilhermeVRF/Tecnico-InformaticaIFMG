﻿<?PHP
error_reporting(0); // NIVEL DE ERRRO DESABILITADO
        if (!empty($_GET['USER'])===false && !empty($_GET['MACHINE'])===false) {
			if (!empty($_COOKIE['USER'])===false && !empty($_COOKIE['MACHINE'])===false) {
				header('Location: pages/examples/401.html');
				exit;
			}else{
				header('Location: '.$uri.'/INTRANET FOB/index.php?%20USER='.$_COOKIE['USER'].'&MACHINE='.$_COOKIE['MACHINE']);
				exit;
			}
        }

	
?>

<?php
function sanitize_output($buffer) {

    $search = array(
        '/\>[^\S ]+/s',     // espaços em branco após etiquetas
        '/[^\S ]+\</s',     // espaços em branco antes das tags
        '/(\s)+/s',         // encurtar múltiplas sequências de espaços em branco
        '/<!--(.|\s)*?-->/' // Remover comentários HTML
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );

    $buffer = preg_replace($search, $replace, $buffer);
	unset($search);
	unset($replace);
    return $buffer;
}

ob_start("sanitize_output");
ini_set('zlib.output_compression','On');
ini_set('zlib.output_compression_level','1');
?>
           <?php 
				/*
				 * BLOCO DE CONEXAO BASICA
				 * 
				 */
				include '../../conexao.php';
				try {
					$conn = new PDO('mysql:host=localhost;dbname='.$db, $username, $password);
					$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);    
					 
					$stmt = $conn->prepare('SELECT CHAPA, EMAIL, NOME, USER, gestor, ti, rh, contab FROM `info_usuario` WHERE USER = :id LIMIT 1');
					$stmt->execute(array('id' => base64_decode($_GET['USER'])));
					$row = $stmt->fetch();
							//--LIMPA VARIAVEIS	
							unset($db);
							unset($username);
							unset($password);
							//--LIMPA VARIAVEIS	
			if($_COOKIE['AUTRH'] != hash('sha512','25E9E02BB52A66E98E0AEA21E62A9A171632C7595FCAFA4F51119212F1F5ABD9FC8502F11B7CCE102C389A71BA23EF11FBEDC0A4FFF5F30B02F536DAFD4A7BA3')){
					if ($_COOKIE[base64_decode($_GET['USER']).'AUT'] != hash('sha512',base64_decode($_GET['USER']).'25E9E02BB52A66E98E0AEA21E62A9A171632C7595FCAFA4F51119212F1F5ABD9FC8502F11B7CCE102C389A71BA23EF11FBEDC0A4FFF5F30B02F536DAFD4A7BA3')){
						$url = 'http://fobnet/INTRANET%20FOB/pages/examples/401.html';
						echo'<META HTTP-EQUIV=Refresh CONTENT="0; URL='.$url.'">';
						header('Location: '.$uri.'/INTRANET FOB/index.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE']);
						exit;
						
					}
				}

					//print_r($row);
					//print $row["NOME"];
				} catch(PDOException $e) {
					echo 'ERROR: ' . $e->getMessage();
				}
			if($row["ti"]==0){
				ECHO '<meta http-equiv="refresh" content=1;url="../../index.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'">';
				header('Location: '.$uri.'/INTRANET FOB/index.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE']);
				exit;
			}
						$chapa = $row["CHAPA"];
						$gestor = $row["gestor"];
						global $gestor;
						$ti = $row["ti"];
						global $ti;
						$rh = $row["rh"];
						global $rh;
						global $chapa;
									//-------Limpa Variaveis---------
							unset($stmt);
							unset($conn);
							unset($count);
							unset($row);
			 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Softwares Instalados no equipamento <?php echo base64_decode($_GET['meta']).' - '.base64_decode($_GET['metadesc'])?></title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="../../fontes/css.css" rel="stylesheet" type="text/css">
    <link href="../../fontes/icon.css" rel="stylesheet" type="text/css">


    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
</head>

<body>
        <div class="container-fluid">
            <div class="block-header">
                <h2>
                    <br>SOFTWARES INSTALADOS
                    <small>Listando softwares instalados na máquina.</small>
                </h2>
            </div>
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                MAQUINA: <?php echo base64_decode($_GET['M']);?>
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Ajuda</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                        <th>Software</th>
                                            <th>Versão</th>
                                            <th>Instalação</th>
                                            <th>Caminho</th>
                                            <th>...</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Software</th>
                                            <th>Versão</th>
                                            <th>Instalação</th>
                                            <th>Caminho</th>
                                            <th>...</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php 
                                        /*
                                        * BLOCO DE CONEXAO BASICA
                                        * 
                                        */
                                        include '../../conexao.php';

                                        $softwares = null;
                                        try {
                                            $conn = new PDO('mysql:host=localhost;dbname='.$db, $username, $password);
                                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                            $stmt = $conn->prepare("SELECT Maquina, Soft_Name, Soft_Version, Soft_InstallDate, Soft_Installlocation FROM hw_inventario_soft WHERE MAQUINA = :id");
                                            $stmt->execute(array('id' => base64_decode($_GET['M'])));
                                            while($row = $stmt->fetch()) {
                                                $Maquina = $row['Maquina'];
                                                $Soft_Name = $row['Soft_Name'];
                                                $Soft_Version = $row['Soft_Version'];
                                                $Soft_InstallDate = $row['Soft_InstallDate'];
                                                $Soft_Installlocation = $row['Soft_Installlocation'];
                                                echo 
                                                    '<tr>'.
                                                    '<td>'.$Soft_Name.'</td>'.
                                                    '<td>'.$Soft_Version.'</td>'.
                                                    '<td>'.$Soft_InstallDate.'</td>'.
                                                    '<td>'.$Soft_Installlocation.'</td>'.
                                                    '<td>
                                                        <a href="pagina_softwares_maquina.php? USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'&S='.base64_encode($Soft_Name).'">
                                                            <li class="material-icons">desktop_windows</li>
                                                        </a>
                                                    </td>';
                                            }
                                        } catch(PDOException $e) {
                                            echo 'ERROR: ' . $e->getMessage();
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>

    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="../../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
</body>

</html>
<?php
ob_end_flush(); 
?>