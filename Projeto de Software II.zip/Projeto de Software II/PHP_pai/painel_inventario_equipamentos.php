﻿
<?PHP
        if (!empty($_GET['USER'])===false && !empty($_GET['MACHINE'])===false) {
			if (!empty($_COOKIE['USER'])===false && !empty($_COOKIE['MACHINE'])===false) {
				header('Location: pages/examples/401.html');
				exit;
			}else{
				header('Location: '.$uri.'/INTRANET FOB/index.php?%20USER='.$_COOKIE['USER'].'&MACHINE='.$_COOKIE['MACHINE']);
				exit;
			}
        }

	
?>

<?php
function sanitize_output($buffer) {

    $search = array(
        '/\>[^\S ]+/s',     // espaços em branco após etiquetas
        '/[^\S ]+\</s',     // espaços em branco antes das tags
        '/(\s)+/s',         // encurtar múltiplas sequências de espaços em branco
        '/<!--(.|\s)*?-->/' // Remover comentários HTML
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );

    $buffer = preg_replace($search, $replace, $buffer);
	unset($search);
	unset($replace);
    return $buffer;
}

ob_start("sanitize_output");
ini_set('zlib.output_compression','On');
ini_set('zlib.output_compression_level','1');
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>INTRANET FOB</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="../../fontes/css.css" rel="stylesheet" type="text/css">
    <link href="../../fontes/icon.css" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
</head>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Aguarde...</p>
			<p>Listando usuários do FOBNET.</p>
        </div>
    </div>
<!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">Buscar</i>
        </div>
        <input type="text" placeholder="Digite o que quer buscar...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="../../index.php?%20USER=<?php echo $_GET['USER'];?>&MACHINE=<?php echo $_GET['MACHINE'];?>">Intranet Hospital Funda&ccedil;&atilde;o Ouro Branco</a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- Call Search -->
                    <li><a href="javascript:void(0);" class="js-search" data-close="true"><i class="material-icons">search</i></a></li>
                    <!-- #END# Call Search -->
                     <!-- Notifications -->
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">notifications</i>
                            <span class="label-count">0</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">NOTIFICAÇÃO</li>
                            <li class="body">
                                <ul class="menu">
                                    <li> 
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-blue-grey">
                                                <i class="material-icons">comment</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4><b>Nehuma</b> notifica&ccedil;&atilde;o</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> Agora
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">Ver todas as notifica&ccedil;&atilde;es</a>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Notifications -->
                    <!-- Tasks -->
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">flag</i>
                            <span class="label-count">0</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">TAREFAS</li>
                            <li class="body">
                                <ul class="menu tasks">
                                    
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">Ver todas as tarefas</a>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Tasks -->
                    <li class="pull-right"><a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i class="material-icons">more_vert</i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
<section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->

           <?php 
				/*
				 * BLOCO DE CONEXAO BASICA
				 * 
				 */
				include '../../conexao.php';
				try {
					$conn = new PDO('mysql:host=localhost;dbname='.$db, $username, $password);
					$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);    
					 
					$stmt = $conn->prepare('SELECT CHAPA, EMAIL, NOME, USER, gestor, ti, rh, contab FROM `info_usuario` WHERE USER = :id LIMIT 1');
					$stmt->execute(array('id' => base64_decode($_GET['USER'])));
					$row = $stmt->fetch();
							//--LIMPA VARIAVEIS	
							unset($db);
							unset($username);
							unset($password);
							//--LIMPA VARIAVEIS	
					echo '<div class="user-info">
                <div class="image">
                    <img src="../../totvs_fotos/'.$row['CHAPA'].'.jpg" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div id="nome_colaborador" class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'.ucwords(strtolower($row['NOME'])).'</div>
                    <div class="email">'.strtolower($row['EMAIL']).'</div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);"><i class="material-icons">person</i>Perfil</a></li>
                            <li role="seperator" class="divider"></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">email</i>Notificacoes</a></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">build</i>Configurações</a></li>
                            <li role="seperator" class="divider"></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">input</i>Sair</a></li>
                        </ul>
                    </div>
                </div>
            </div>';
			if($_COOKIE['AUTRH'] != hash('sha512','25E9E02BB52A66E98E0AEA21E62A9A171632C7595FCAFA4F51119212F1F5ABD9FC8502F11B7CCE102C389A71BA23EF11FBEDC0A4FFF5F30B02F536DAFD4A7BA3')){
					if ($_COOKIE[base64_decode($_GET['USER']).'AUT'] != hash('sha512',base64_decode($_GET['USER']).'25E9E02BB52A66E98E0AEA21E62A9A171632C7595FCAFA4F51119212F1F5ABD9FC8502F11B7CCE102C389A71BA23EF11FBEDC0A4FFF5F30B02F536DAFD4A7BA3')){
						$url = 'http://fobnet/INTRANET%20FOB/pages/examples/401.html';
						echo'<META HTTP-EQUIV=Refresh CONTENT="0; URL='.$url.'">';
						
					}
				}
					//print_r($row);
					//print $row["NOME"];
				} catch(PDOException $e) {
					echo 'ERROR: ' . $e->getMessage();
				}
			if($row["ti"]==0){
				ECHO '<meta http-equiv="refresh" content=1;url="../../index.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'">';
				header('Location: '.$uri.'/INTRANET FOB/index.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE']);
				exit;
			}
						$chapa = $row["CHAPA"];
						$gestor = $row["gestor"];
						global $gestor;
						$ti = $row["ti"];
						global $ti;
						$rh = $row["rh"];
						global $rh;
						global $chapa;
									//-------Limpa Variaveis---------
							unset($stmt);
							unset($conn);
							unset($count);
							unset($row);
			 ?>
            <!-- #User Info -->
<!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MENU PRINCIPAL</li>
                    <li class="active">
                        <a href="../../index.php?%20USER=<?php echo $_GET['USER'];?>&MACHINE=<?php echo $_GET['MACHINE'];?>">
                            <i class="material-icons">home</i>
                            <span>Pagina Inicial</span>
                        </a>
                    </li>
                    <li class="header">MENU RESTRITO</li>
					<?php

					if($gestor == '1'){
					echo '<li>
                        <a href="../../gestor.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'" data-toggle="tooltip" data-placement="right" title="Gerencie sua equipe, aprove f&eacute;rias, aprove horas extras.">
                            <i class="material-icons" >local_mall</i>
                            <span>Gestor</span>
                        </a>
                    </li>';
					}
					if($rh == '1'){
						echo '<li>
                        <a href="../../rh.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'" data-toggle="tooltip" data-placement="right" title="Ferramentas operacionais RH.">
                            <i class="material-icons" >group</i>
                            <span>RH</span>
                        </a>
                    </li>';
					}
					if($ti == '1'){
					echo '<li>
							<a href="../../ti.php?%20USER='.$_GET['USER'].'&MACHINE='.$_GET['MACHINE'].'" data-toggle="tooltip" data-placement="right" title="Ferramentas operacionais TI.">
								<i class="material-icons" >laptop_chromebook</i>
								<span>TI</span>
							</a>
						</li>';	
					}
					
					?>
					<li>
                    <li>
                        <a href="../changelogs.php?%20USER=<?php echo $_GET['USER'];?>&MACHINE=<?php echo $_GET['MACHINE'];?>">
                            <i class="material-icons">update</i>
                            <span>Sobre</span>
                        </a>
                    </li>
                    <li class="header">NOTIFICA&Ccedil;&Otilde;ES</li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="material-icons col-red">donut_large</i>
                            <span>Importante</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="material-icons col-amber">donut_large</i>
                            <span>Alertas</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="material-icons col-light-blue">donut_large</i>
                            <span>Informa&ccedil;&atilde;o</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
			<p> <img src="../../images/fob2.jpg" width="80" height="80" align="left">
			    <div class="copyright">
				<br>
                </div>
                <div class="copyright">
                    &copy; 2017 <a href="javascript:void(0);">Hospital FOB</a>.
                </div>
                <div class="version">
                    <b>Version: Beta </b> 1.0.0
                </div>
			</p>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar">
            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                <li role="presentation" class="active"><a href="#skins" data-toggle="tab">Cores</a></li>
                <li role="presentation"><a href="#settings" data-toggle="tab">Configura&ccedil;&otilde;es</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active in active" id="skins">
                    <ul class="demo-choose-skin">
                        <li data-theme="red" class="active">
                            <div class="red"></div>
                            <span>Vermelho</span>
                        </li>
                        <li data-theme="pink">
                            <div class="pink"></div>
                            <span>Rosa</span>
                        </li>
                        <li data-theme="purple">
                            <div class="purple"></div>
                            <span>Roxo</span>
                        </li>
                        <li data-theme="deep-purple">
                            <div class="deep-purple"></div>
                            <span>Roxo Forte</span>
                        </li>
                        <li data-theme="indigo">
                            <div class="indigo"></div>
                            <span>Indigo</span>
                        </li>
                        <li data-theme="blue">
                            <div class="blue"></div>
                            <span>Azul</span>
                        </li>
                        <li data-theme="light-blue">
                            <div class="light-blue"></div>
                            <span>Azul Claro</span>
                        </li>
                        <li data-theme="cyan">
                            <div class="cyan"></div>
                            <span>Ciano</span>
                        </li>
                        <li data-theme="teal">
                            <div class="teal"></div>
                            <span>Cerceta</span>
                        </li>
                        <li data-theme="green">
                            <div class="green"></div>
                            <span>Verde</span>
                        </li>
                        <li data-theme="light-green">
                            <div class="light-green"></div>
                            <span>Verde Claro</span>
                        </li>
                        <li data-theme="lime">
                            <div class="lime"></div>
                            <span>Lima</span>
                        </li>
                        <li data-theme="yellow">
                            <div class="yellow"></div>
                            <span>Amarelo</span>
                        </li>
                        <li data-theme="amber">
                            <div class="amber"></div>
                            <span>Ambar</span>
                        </li>
                        <li data-theme="orange">
                            <div class="orange"></div>
                            <span>Laranja</span>
                        </li>
                        <li data-theme="deep-orange">
                            <div class="deep-orange"></div>
                            <span>Laranja Forte</span>
                        </li>
                        <li data-theme="brown">
                            <div class="brown"></div>
                            <span>Castanho</span>
                        </li>
                        <li data-theme="grey">
                            <div class="grey"></div>
                            <span>Cinzento</span>
                        </li>
                        <li data-theme="blue-grey">
                            <div class="blue-grey"></div>
                            <span>Azul Cinzento</span>
                        </li>
                        <li data-theme="black">
                            <div class="black"></div>
                            <span>Preto</span>
                        </li>
                    </ul>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="settings">
                    <div class="demo-settings">
                        <p>Configura&ccedil;&otilde;es Gerais</p>
                        <ul class="setting-list">
                            <li>
                                <span>Uso do Painel de Relatórios</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Redirecionar Email</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>Configura&ccedil;&otilde;es do Sistema</p>
                        <ul class="setting-list">
                            <li>
                                <span>Notifica&ccedil;&otilde;es</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Auto Updates</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>Configura&ccedil;&otilde;es da Conta</p>
                        <ul class="setting-list">
                            <li>
                                <span>Offline</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Permissão de localiza&ccedil;&atilde;o</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </section>

    <section class="content">
		<form id="form2" action="grava.php?%20USER=<?php echo $_GET['USER'];?>&MACHINE=<?php echo $_GET['MACHINE'];?>" method="post">
					<input type="hidden" name="chapa" id="chapa">
					<input type="hidden" name="tipo" id="tipo">
		</form>
        <div class="container-fluid">
            <div class="block-header">
                <h2>
                    GEST&Atilde;O DE DISPOSITIVOS
                    <small>Opera&ccedil;&otilde;es com dispositivos ativos no dominio</small>
                </h2>
            </div>
            <!-- Basic Examples -->
            <!-- #END# Basic Examples -->
            <!-- Exportable Table -->
            <div class="body">
            <a href="#" onclick="javascript:window.open('../forms/lista_maquinas_ad.php?%20USER=<?php echo $_GET['USER'];?>&MACHINE=<?php echo $_GET['MACHINE'];?>', 'yourWindowName', 'width=800,height=800,toolbar=no,location=no, directories=no, status=no, menubar=no');"><button data-toggle="tooltip" data-placement="bottom" title="Sincronizar com o AD." type="button" class="btn bg-green waves-effect"><i class="material-icons">call_split</i><span>Sincronizar com o AD</span></button></a><br><hr>
                <div class="table-responsive-sm">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th>...</th>
                                <th>Nome do Computador</th>
                                <th>Último Usuário</th>
                                <th>Cadastro no TASY?</th>
                                <th>Centro de Custo</th>
                                <th>Localização TASY</th>
                                <th>Modelo do Computador</th>
                                <th>Fabricante do Computador</th>
                                <th>Memória RAM</th>
                                <th>Sistema Operacional</th>
                                <th>Partição do Sistema</th>
                                <th>Versão do Sistema</th>
                                <th>Arquitetura do Sistema</th>
                                <th>Número de Série</th>
                                <th>Fabricante da Placa Mãe</th>
                                <th>Serial da Placa Mãe</th>
                                <th>Versão da Placa Mãe</th>
                                <th>BIOS</th>
                                <th>Arquitetura do Processador</th>
                                <th>AssetTag do Processador</th>
                                <th>Modelo do Processador</th>
                                <th>Fabricante do Processador</th>
                                <th>Núcleos do Processador</th>
                                <th>Núcleos do Processador Ativos</th>
                                <th>Nome do Processador</th>
                                <th>Núcleos Lógicos do Processador</th>
                                <th>Informações de HD</th>
                                <th>Informações de Memória RAM</th>
                                <th>MAC Address da Placa de Rede</th>
                                <th>Velocidade da Placa de Rede</th>
                                <th>Controlador de Domínio</th>
                                <th>Nome do Domínio</th>
                                <th>Atualização</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>...</th>
                                <th>Nome do Computador</th>
                                <th>Último Usuário</th>
                                <th>Cadastro no TASY?</th>
                                <th>Centro de Custo</th>
                                <th>Localização TASY</th>
                                <th>Modelo do Computador</th>
                                <th>Fabricante do Computador</th>
                                <th>Memória RAM</th>
                                <th>Sistema Operacional</th>
                                <th>Partição do Sistema</th>
                                <th>Versão do Sistema</th>
                                <th>Arquitetura do Sistema</th>
                                <th>Número de Série</th>
                                <th>Fabricante da Placa Mãe</th>
                                <th>Serial da Placa Mãe</th>
                                <th>Versão da Placa Mãe</th>
                                <th>BIOS</th>
                                <th>Arquitetura do Processador</th>
                                <th>AssetTag do Processador</th>
                                <th>Modelo do Processador</th>
                                <th>Fabricante do Processador</th>
                                <th>Núcleos do Processador</th>
                                <th>Núcleos do Processador Ativos</th>
                                <th>Nome do Processador</th>
                                <th>Núcleos Lógicos do Processador</th>
                                <th>Informações de HD</th>
                                <th>Informações de Memória RAM</th>
                                <th>MAC Address da Placa de Rede</th>
                                <th>Velocidade da Placa de Rede</th>
                                <th>Controlador de Domínio</th>
                                <th>Nome do Domínio</th>
                                <th>Atualização</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php 
                            ini_set('max_execution_time', 500000); //300 seconds = 5 minutes
                            /*
                            * BLOCO DE CONEXAO BASICA
                            * 
                            */                                        
                            $tns = "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = racscan)(PORT = 1521))) (CONNECT_DATA = (SERVICE_NAME = fob)))";
                            $db_username = "TASY";
                            $db_password = "aloisk";
                            include '../../conexao.php';
                            $id = 0;
                            $gestor = NULL;
                            $rh = NULL;
                            $destivado = NULL;
                            $cadastrado_no_tasy = NULL;
                            try {
                                $conn = new PDO('mysql:host=localhost;dbname='.$db, $username, $password);
                                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);   
                                $stmt = $conn->prepare("select system_name, system_username, system_model, system_manufacturer, system_TotalPhysicalMemory, os_caption, os_SystemDevice, os_version, os_OSArchitecture, bios_SerialNumber, baseboard_Manufacturer, baseboard_SerialNumber, baseboard_Version, bios_biosversion, cpu_AddressWidth, cpu_AssetTag, cpu_Caption, cpu_Manufacturer, cpu_systemname, cpu_numberofcores, cpu_numberofenabledcore, cpu_name, cpu_numberoflogicalprocessors, disk_information, memory_information, nic_MACAddress, nic_Speed, domain_DomainControllerName, domain_DomainName, date_atz FROM hw_inventario_equip WHERE 1=:id");
                                $stmt->execute(array('id' => '1'));
                                //--LIMPA VARIAVEIS	
                                unset($db);
                                unset($username);
                                unset($password);
                                //--LIMPA VARIAVEIS	
                                $result = $stmt->fetchAll();
                                foreach($result as $row){
                                    //while($row = $stmt->fetch()) {
                                    //Conecta ao Tasy
                                    $conn2 = new PDO("oci:dbname=".$tns,$db_username,$db_password);
                                    $conn2->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);    
                                    $stmt2 = $conn2->prepare("SELECT COUNT(CD_CONTROLE), (SELECT (SELECT CONCAT(CONCAT(A.cd_centro_custo,'-'),A.DS_CENTRO_CUSTO) FROM CENTRO_CUSTO A WHERE A.cd_centro_custo = B.cd_centro_custo and ROWNUM < 2) FROM MAN_EQUIPAMENTO B WHERE B.CD_CONTROLE = :id and B.ie_situacao = 'A' and ROWNUM < 2) AS CCUSTO, (SELECT MAN_LOCALIZACAO.DS_LOCALIZACAO FROM MAN_LOCALIZACAO WHERE man_localizacao.nr_sequencia = MAN_EQUIPAMENTO.NR_SEQ_LOCAL) AS LOCAL FROM MAN_EQUIPAMENTO WHERE CD_CONTROLE = :id AND ie_situacao = 'A' GROUP BY CD_CONTROLE, NR_SEQ_LOCAL");
                                    $stmt2->execute(array('id' => $row['system_name']));
                                    $result2 = $stmt2->fetch();
                                    if($result2[0] == 0){
                                        $cadastrado_no_tasy = '<span class="label label-warning">Não Cadastrado no Tasy [0]</span>';
                                    }else{
                                        $cadastrado_no_tasy = '<span class="label label-success">Cadastrado no Tasy ['.$result2[0].']</span>';
                                    }
                                        echo 
                                            '<tr>'.
                                            '<td>'.'
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="material-icons">settings</i>
                                                        <span class="caret"></span>
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a href="" onclick="javascript:window.open'."('pagina_softwares_instalados.php? USER=".$_GET['USER']."&MACHINE=".$_GET['MACHINE']."&M=".base64_encode($row['system_name'])."'".", 'yourWindowName', 'width=1000,height=800,toolbar=no,location=no, directories=no, status=no, menubar=no');".'"'.' class=" waves-effect waves-block"><i class="material-icons">done_all</i>Softwares</a>
                                                        </li>
                                                        <li>
                                                            <a href="#" onclick="javascript:window.open'."('log_acesso.php? USER=".$_GET['USER']."&MACHINE=".$_GET['MACHINE']."&M=".base64_encode($row['system_name'])."'".", 'yourWindowName', 'width=800,height=800,toolbar=no,location=no, directories=no, status=no, menubar=no');".'"'.' class=" waves-effect waves-block"><i class="material-icons">block</i>Log Acesso</a>
                                                        </li>
                                                        <li>
                                                            <a href="#" onclick="javascript:window.open'."('maquina_systeminfo.php? USER=".$_GET['USER']."&MACHINE=".$_GET['MACHINE']."&M=".base64_encode($row['system_name'])."'".", 'yourWindowName', 'width=800,height=800,toolbar=no,location=no, directories=no, status=no, menubar=no');".'"'.' class=" waves-effect waves-block"><i class="material-icons">error</i>Systeminfo agora.</a></li><li role="Alerta" class="divider"></li><li><a href="" class=" waves-effect waves-block"><i class="material-icons">clear</i>Exclusão</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>'.
                                            '<td>'.$row['system_name'].'</td>'.
                                            '<td>'.$row['system_username'].'</td>'.
                                            '<td>'.$cadastrado_no_tasy.'</td>'.
                                            '<td>'.utf8_encode($result2[1]).'</td>'.
                                            '<td>'.utf8_encode($result2[2]).'</td>'.
                                            '<td>'.$row['system_model'].'</td>'.
                                            '<td>'.$row['system_manufacturer'].'</td>'.
                                            '<td>'.$row['system_TotalPhysicalMemory'].'</td>'.
                                            '<td>'.$row['os_caption'].'</td>'.
                                            '<td>'.$row['os_SystemDevice'].'</td>'.
                                            '<td>'.$row['os_version'].'</td>'.
                                            '<td>'.$row['os_OSArchitecture'].'</td>'.
                                            '<td>'.$row['bios_SerialNumber'].'</td>'.
                                            '<td>'.$row['baseboard_Manufacturer'].'</td>'.
                                            '<td>'.$row['baseboard_SerialNumber'].'</td>'.
                                            '<td>'.$row['baseboard_Version'].'</td>'.
                                            '<td>'.$row['bios_biosversion'].'</td>'.
                                            '<td>'.$row['cpu_AddressWidth'].'</td>'.
                                            '<td>'.$row['cpu_AssetTag'].'</td>'.
                                            '<td>'.$row['cpu_Caption'].'</td>'.
                                            '<td>'.$row['cpu_Manufacturer'].'</td>'.
                                            '<td>'.$row['cpu_numberofcores'].'</td>'.
                                            '<td>'.$row['cpu_numberofenabledcore'].'</td>'.
                                            '<td>'.$row['cpu_name'].'</td>'.
                                            '<td>'.$row['cpu_numberoflogicalprocessors'].'</td>'.
                                            '<td>'.$row['disk_information'].'</td>'.
                                            '<td>'.$row['memory_information'].'</td>'.
                                            '<td>'.$row['nic_MACAddress'].'</td>'.
                                            '<td>'.$row['nic_Speed'].'</td>'.
                                            '<td>'.$row['domain_DomainControllerName'].'</td>'.
                                            '<td>'.$row['domain_DomainName'].'</td>'.
                                            '<td>'.$row['date_atz'].'</td>'.
                                            '</tr>';
                                    //-LIMPA VARIAVEIS
                                    $gestor = NULL;
                                    $rh = NULL;
                                    //-LIMPA VARIAVEIS
                                }//Fim do while
                            } catch(PDOException $e) {
                                echo 'ERROR: ' . $e->getMessage();
                            }
                            //-------Limpa Variaveis---------
                            unset($stmt);
                            unset($conn);
                            unset($count);
                            unset($row);
                            unset($result);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="../../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../../js/admin.js"></script>
    <script src="../../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
<?php
ob_end_flush(); 
?>
</body>

</html>
