<?php                        
                    define('HOST', 'localhost');
                    define('USER', 'root'); 
                    define('PASSWORD', ''); 
                    define('DB', 'carrinho_bd'); 
                   
                   try { 
                     $conn = new mysqli(HOST, USER, PASSWORD, DB);
                     echo "Connected successfully";
                    }catch (mysqliException $error) {
                     echo 'Connection error: ' . $error->getMessage();
                    }
       
                   $select = $conn->prepare("SELECT Nm_produto, Preco_produto, Qtde_produto, Nm_cliente, telefone_cliente, data_pedido FROM carrinho WHERE Nm_cliente = 'Claudio'");

                   if ($select->execute()) {
                    while($row = $select->fetch()) {
                        $Nm_cliente = $row['Nm_cliente'];
                        $Telefone_cliente = $row['telefone_cliente'];
                        $Nm_produto = $row['Nm_produto'];
                        $preco_produto = $row['Preco_produto'];
                        $qtde = $row['Qtde_produto'];
                        $data_pedido= $row['data_pedido'];
                        echo 
                            '<tr>'.
                            '<td>'.$Nm_cliente.'</td>'.
                            '<td>'.$Telefone_cliente.'</td>'.
                            '<td>'.$Nm_produto.'</td>'.
                            '<td>'.$preco_produto.'</td>'.
                            '<td>'.$qtde.'</td>'.
                            '<td>'.$data_pedido.'</td>'.
                            '<td>                               
                            </td>';
                  } else {
                    echo "Unable to create record";
                  }   