<?php 
$username = 'root';
$password = ''; 
$db = 'FOB';
?>