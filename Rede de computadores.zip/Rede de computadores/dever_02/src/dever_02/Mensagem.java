
package dever_02;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
public class Mensagem implements Serializable {
	private String nome;
	private String texto;
	private String DataHora;
	public Mensagem() {
		super();
	}
	
	public Mensagem(String nome, String texto) {
		super();
		this.nome = nome;
		this.texto = texto;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTexto() {
		return texto;
	}
        public void setDataHora(String DataHora){
        this.DataHora = DataHora; 
        }
	public void setTexto(String texto) {
		this.texto = texto;
	}   
	@Override
	public String toString() {
		return "Mensagem [nome=" + nome + ", texto=" + texto + "]";
	}
	
}

