package um;

import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TrataCliente {
		
	private Socket soquete_cliente;
	private ObjectOutputStream saida;
	private ObjectInputStream entrada;

	public TrataCliente(Socket soquete_cliente) throws Exception {
		super();
		this.soquete_cliente = soquete_cliente;
		this.saida = new ObjectOutputStream(this.soquete_cliente.getOutputStream()); 
		this.entrada = new ObjectInputStream(this.soquete_cliente.getInputStream());
	}
	
	public void enviar_mensagem(Object mensagem) throws Exception {
		this.saida.writeObject(mensagem);
	}
	
	public Object receber_mensagem() throws Exception {
		return this.entrada.readObject();
	}
	
	public void finalizar() throws IOException {
		this.soquete_cliente.close();
	}
	
	public void iniciar() throws Exception {
        
        boolean c = true;
        String resposta = "";
        String L = (String)receber_mensagem();
        
            if (L.contains("Charles")){
                c = false;
                System.out.println("Mensagem do Cliente: " + L);
                resposta= "CADASTRADA";
            }    
            if (L.contains("Fulano")){
                c = false;
                System.out.println("Mensagem do Cliente: " + L);
                resposta= "CADASTRADA";
            }  
            if (L.contains("Ciclano")){
                c = false;
                System.out.println("Mensagem do Cliente: " + L);
                resposta= "CADASTRADA";
            }  
            if (L.contains("Beltrano")){
                c = false;
                System.out.println("Mensagem do Cliente: " + L);
                resposta= "CADASTRADA";
            }   
            
            if (c==true){
                
                System.out.println("Mensagem do Cliente: " + L);
                resposta = "NAO CADASTRADA";
            }
            
            enviar_mensagem(resposta);
            finalizar();
        }
}
