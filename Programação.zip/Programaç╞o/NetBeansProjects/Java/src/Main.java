
public class  {  
   public static void Java(String[] args) { 
    String s = "Welcome to Baeldung"; 
   String expected1 = "Welcome to Baeldung"; 
   String expected2 = "Welcome to Baeldung"; 
assertArrayEquals(expected1, s.split(" ")); assertArrayEquals(expected2, s.split(" ", 2)); 
    }

    private static void assertArrayEquals(String expected1, String[] split) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}  