/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication53;

/**
 *
 * @author Jabas
 */
public class JavaApplication53 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String titulo = "Livo";
        String editora = "Eduardo";
        String autor = "ferreira";
        int preco = 22;
               
       System.out.println(" Título: "+titulo+"\n Editora: "+editora+"\n Autor: "+autor+"\n Preço: "+preco);
    }
    
}
