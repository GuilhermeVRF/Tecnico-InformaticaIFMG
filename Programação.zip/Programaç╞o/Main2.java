
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
      Scanner Teclado = new Scanner(System.in);
      int N1 = Teclado.nextInt();
      int N2 = Teclado.nextInt();
      int N3 = Teclado.nextInt();
      if((N1>N2) & (N1>N3) & (N2>N3)){
       System.out.println(N1+"\n"+N2+"\n"+N3);
      }
      if((N1>N2)& (N1>N3) & (N3>N2)){
       System.out.println(N1+"\n"+N3+"\n"+N2);
      }
      if((N2>N1) & (N2>N3) & (N1>N3)){
        System.out.println(N2+"\n"+N1+"\n"+N3);
      }
      if((N2>N1) & (N2>N3) & (N3>N1)){
        System.out.println(N2+"\n"+N3+"\n"+N1);
    }
      if((N3>N1) & (N3>N2) & (N1>N2)){
        System.out.println(N3+"\n"+N1+"\n"+N2);
      }
      if((N3>N1) & (N3>N2) & (N2>N1)){
        System.out.println(N3+"\n"+N2+"\n"+N1);
      }
    }
    
}
