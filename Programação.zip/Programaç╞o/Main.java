
import java.util.Scanner;




public class Main {

    public static void main(String[] args) {
         Scanner Teclado = new Scanner(System.in);
         String X = Teclado.nextLine();
         if(X=="RJ"){
           System.out.println("carioca");
         }
         if(X=="SP"){
           System.out.println("paulista");
         }
         if(X=="MG"){
            System.out.println("mineiro");
         }
         if(X=="RN"){
            System.out.println("potiguar");
         }
         if(X=="ES"){
            System.out.println("capixaba");
         }
         if(X=="RS"){
            System.out.println("gaucho");
         }
         if((X!="RJ") & (X!="SP") & (X!="MG") & (X!="RN") & (X!="ES") & (X!="RS")){
             System.out.println("outro estado");
         }
            }
    }
