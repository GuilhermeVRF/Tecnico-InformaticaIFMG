
import java.util.Scanner;




public class Main {

    public static void main(String[] args) {
      Scanner Teclado = new Scanner(System.in);
      int N1 = Teclado.nextInt();
      int N2 = Teclado.nextInt();
      int N3 = Teclado.nextInt();
      int N4 = Teclado.nextInt();
      if((N1<N2) & (N1<N3) & (N1<N4)){
        System.out.println(N1);
      }
      if((N2<N1) & (N2<N3) & (N2<N4)){
        System.out.println(N2);
      }
      if((N3<N1) & (N3<N2) & (N3<N4)){
        System.out.println(N3);
    }
      if((N4<N1) & (N4<N2) & (N4<N3)){
        System.out.println(N4);
      }
    }
}
